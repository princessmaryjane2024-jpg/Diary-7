# Baby Tomato Diary — Android Studio Project

A native Android implementation of the Baby Tomato Diary reorganized into a Writez-style workspace:

**Projects → Chapters → Writing Editor**

Features:
- Multiple diary projects
- Multiple chapters per project
- Dedicated writing editor
- Local on-device saving with SharedPreferences
- Word count
- New/delete project and chapter
- Mobile navigation between Projects, Chapters, and Editor

## Build
Open the `BabyTomatoDiary` folder in Android Studio. Let Gradle sync, then run the `app` configuration on a device/emulator. Android Studio/Gradle may download the Android Gradle Plugin and SDK components if they are not already installed.

Minimum Android version: Android 6.0 (API 23)
Target SDK: 35
